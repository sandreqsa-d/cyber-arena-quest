import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Lock, CheckCircle } from "lucide-react";

interface TopicCardProps {
  id: string;
  name: string;
  icon: string;
  color: string;
  progress?: {
    quizzes: number;
    games: number;
    completed: boolean;
  };
  locked?: boolean;
  index: number;
}

export function TopicCard({ id, name, icon, color, progress, locked, index }: TopicCardProps) {
  const totalProgress = progress 
    ? ((progress.quizzes + progress.games) / 10) * 100 
    : 0;

  return (
    <Link 
      to={locked ? "#" : `/topic/${id}`}
      className={`block ${locked ? 'cursor-not-allowed' : ''}`}
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <Card 
        glow={!locked}
        className={`relative overflow-hidden h-48 group transition-all duration-500 animate-fade-in ${
          locked ? 'opacity-50' : 'hover:scale-[1.02] hover:-translate-y-1'
        }`}
      >
        {/* Gradient overlay */}
        <div className={`absolute inset-0 bg-gradient-to-br ${color} opacity-10 group-hover:opacity-20 transition-opacity duration-500`} />
        
        {/* Content */}
        <div className="relative z-10 p-6 h-full flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <span className="text-4xl">{icon}</span>
            {progress?.completed && (
              <CheckCircle className="w-6 h-6 text-success" />
            )}
            {locked && (
              <Lock className="w-6 h-6 text-muted-foreground" />
            )}
          </div>
          
          <div>
            <h3 className="font-display text-lg font-semibold text-foreground mb-2">
              {name}
            </h3>
            
            {progress && !locked && (
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Progress</span>
                  <span>{Math.round(totalProgress)}%</span>
                </div>
                <Progress value={totalProgress} className="h-1.5" />
              </div>
            )}
            
            {locked && (
              <p className="text-xs text-muted-foreground">
                Unlock with Premium
              </p>
            )}
          </div>
        </div>

        {/* Hover glow effect */}
        <div className={`absolute inset-0 bg-gradient-to-br ${color} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} />
      </Card>
    </Link>
  );
}
