import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Gift, Eye, EyeOff, CheckCircle } from "lucide-react";
import { claimVoucher } from "@/lib/storage";

interface VoucherCardProps {
  topicId: string;
  topicName: string;
  topicIcon: string;
  voucherId: string;
  claimed: boolean;
  onClaim: () => void;
}

export function VoucherCard({ topicId, topicName, topicIcon, voucherId, claimed, onClaim }: VoucherCardProps) {
  const [revealed, setRevealed] = useState(false);
  const [localClaimed, setLocalClaimed] = useState(claimed);

  const handleClaim = () => {
    claimVoucher(topicId);
    setLocalClaimed(true);
    onClaim();
  };

  return (
    <Card glow className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-secondary/10" />
      
      <div className="relative z-10 p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-2xl">
            {topicIcon}
          </div>
          <div>
            <h3 className="font-display font-semibold text-foreground">{topicName}</h3>
            <p className="text-sm text-muted-foreground">Reward Voucher</p>
          </div>
          {localClaimed && (
            <CheckCircle className="ml-auto w-6 h-6 text-success" />
          )}
        </div>

        <div className="bg-muted rounded-lg p-4 mb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gift className="w-5 h-5 text-primary" />
              <span className="text-sm text-muted-foreground">Voucher ID:</span>
            </div>
            {localClaimed && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setRevealed(!revealed)}
                className="gap-2"
              >
                {revealed ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                {revealed ? 'Hide' : 'Reveal'}
              </Button>
            )}
          </div>
          
          <div className="mt-2 font-mono text-xl font-bold text-center py-2">
            {localClaimed && revealed ? (
              <span className="text-primary text-glow">{voucherId}</span>
            ) : (
              <span className="text-muted-foreground">••••••</span>
            )}
          </div>
        </div>

        {!localClaimed && (
          <Button 
            variant="cyber" 
            className="w-full"
            onClick={handleClaim}
          >
            Claim Voucher
          </Button>
        )}
      </div>
    </Card>
  );
}
