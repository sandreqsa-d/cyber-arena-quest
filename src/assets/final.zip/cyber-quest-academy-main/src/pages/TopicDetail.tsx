import { useParams, Navigate, Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { TOPICS, getCurrentUser, updateUserProgress } from "@/lib/storage";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Gamepad2, Brain, Trophy, CheckCircle, Play } from "lucide-react";
import { useState } from "react";

const TopicDetail = () => {
  const { topicId } = useParams();
  const topic = TOPICS.find(t => t.id === topicId);
  const user = getCurrentUser();
  const [refreshKey, setRefreshKey] = useState(0);

  if (!topic) {
    return <Navigate to="/topics" replace />;
  }

  const progress = user?.progress.find(p => p.topicId === topic.id);
  const quizzesCompleted = progress?.quizScores.length || 0;
  const gamesCompleted = progress?.gameScores.length || 0;
  const totalProgress = ((quizzesCompleted + gamesCompleted) / 10) * 100;

  const handleCompleteGame = (gameIndex: number) => {
    if (!user) return;
    const score = Math.floor(Math.random() * 40) + 60; // Random score 60-100
    updateUserProgress(topic.id, undefined, score);
    setRefreshKey(prev => prev + 1);
  };

  const handleCompleteQuiz = (quizIndex: number) => {
    if (!user) return;
    const score = Math.floor(Math.random() * 40) + 60; // Random score 60-100
    updateUserProgress(topic.id, score);
    setRefreshKey(prev => prev + 1);
  };

  // Re-fetch user after updates
  const currentUser = getCurrentUser();
  const currentProgress = currentUser?.progress.find(p => p.topicId === topic.id);
  const currentQuizzes = currentProgress?.quizScores.length || 0;
  const currentGames = currentProgress?.gameScores.length || 0;

  return (
    <div className="min-h-screen bg-background cyber-grid">
      <Navbar />
      
      <div className="container mx-auto px-4 pt-32 pb-20">
        <Link to="/topics" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" />
          Back to Topics
        </Link>

        {/* Topic Header */}
        <div className="flex items-center gap-6 mb-12 animate-fade-in">
          <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${topic.color} flex items-center justify-center text-4xl`}>
            {topic.icon}
          </div>
          <div className="flex-1">
            <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-2">
              {topic.name}
            </h1>
            <div className="flex items-center gap-4">
              <Progress value={((currentQuizzes + currentGames) / 10) * 100} className="w-48 h-2" />
              <span className="text-sm text-muted-foreground">
                {currentQuizzes + currentGames}/10 Complete
              </span>
            </div>
          </div>
          {currentProgress?.completed && (
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-success/10 text-success border border-success/20">
              <Trophy className="w-5 h-5" />
              <span className="font-semibold">Completed!</span>
            </div>
          )}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Games Section */}
          <div className="animate-fade-in" style={{ animationDelay: '0.1s' }}>
            <div className="flex items-center gap-3 mb-6">
              <Gamepad2 className="w-6 h-6 text-primary" />
              <h2 className="font-display text-xl font-semibold text-foreground">
                Interactive Games
              </h2>
              <span className="text-sm text-muted-foreground ml-auto">
                {currentGames}/5
              </span>
            </div>
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map((level) => {
                const isCompleted = currentGames >= level;
                const isUnlocked = level === 1 || currentGames >= level - 1;
                
                return (
                  <Card 
                    key={level}
                    glow={isUnlocked && !isCompleted}
                    className={`p-4 transition-all duration-300 ${!isUnlocked && 'opacity-50'}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-display font-bold ${
                          isCompleted 
                            ? 'bg-success text-success-foreground' 
                            : 'bg-muted text-muted-foreground'
                        }`}>
                          {isCompleted ? <CheckCircle className="w-5 h-5" /> : level}
                        </div>
                        <div>
                          <h3 className="font-semibold text-foreground">Game Level {level}</h3>
                          <p className="text-sm text-muted-foreground">
                            {level === 1 && 'Introduction'}
                            {level === 2 && 'Basic Concepts'}
                            {level === 3 && 'Intermediate'}
                            {level === 4 && 'Advanced'}
                            {level === 5 && 'Expert Challenge'}
                          </p>
                        </div>
                      </div>
                      {isUnlocked && !isCompleted && user && (
                        <Button 
                          variant="default" 
                          size="sm" 
                          className="gap-2"
                          onClick={() => handleCompleteGame(level)}
                        >
                          <Play className="w-4 h-4" />
                          Play
                        </Button>
                      )}
                      {isCompleted && currentProgress?.gameScores[level - 1] && (
                        <span className="text-sm font-semibold text-success">
                          Score: {currentProgress.gameScores[level - 1]}%
                        </span>
                      )}
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Quizzes Section */}
          <div className="animate-fade-in" style={{ animationDelay: '0.2s' }}>
            <div className="flex items-center gap-3 mb-6">
              <Brain className="w-6 h-6 text-secondary" />
              <h2 className="font-display text-xl font-semibold text-foreground">
                Knowledge Quizzes
              </h2>
              <span className="text-sm text-muted-foreground ml-auto">
                {currentQuizzes}/5
              </span>
            </div>
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map((level) => {
                const isCompleted = currentQuizzes >= level;
                const isUnlocked = level === 1 || currentQuizzes >= level - 1;
                
                return (
                  <Card 
                    key={level}
                    glow={isUnlocked && !isCompleted}
                    className={`p-4 transition-all duration-300 ${!isUnlocked && 'opacity-50'}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-display font-bold ${
                          isCompleted 
                            ? 'bg-success text-success-foreground' 
                            : 'bg-muted text-muted-foreground'
                        }`}>
                          {isCompleted ? <CheckCircle className="w-5 h-5" /> : level}
                        </div>
                        <div>
                          <h3 className="font-semibold text-foreground">Quiz Level {level}</h3>
                          <p className="text-sm text-muted-foreground">
                            {level === 1 && '5 Questions'}
                            {level === 2 && '10 Questions'}
                            {level === 3 && '15 Questions'}
                            {level === 4 && '20 Questions'}
                            {level === 5 && 'Final Assessment'}
                          </p>
                        </div>
                      </div>
                      {isUnlocked && !isCompleted && user && (
                        <Button 
                          variant="secondary" 
                          size="sm" 
                          className="gap-2"
                          onClick={() => handleCompleteQuiz(level)}
                        >
                          <Play className="w-4 h-4" />
                          Start
                        </Button>
                      )}
                      {isCompleted && currentProgress?.quizScores[level - 1] && (
                        <span className="text-sm font-semibold text-success">
                          Score: {currentProgress.quizScores[level - 1]}%
                        </span>
                      )}
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>

        {/* Completion Message */}
        {currentProgress?.completed && (
          <div className="mt-12 animate-fade-in">
            <Card className="p-8 text-center bg-gradient-to-br from-success/10 to-accent/10 border-success/20">
              <Trophy className="w-16 h-16 text-success mx-auto mb-4" />
              <h2 className="font-display text-2xl font-bold text-foreground mb-2">
                Congratulations!
              </h2>
              <p className="text-muted-foreground mb-6">
                You've completed all games and quizzes for {topic.name}. 
                Check your profile to claim your reward voucher!
              </p>
              <Link to="/profile">
                <Button variant="cyber">View Your Voucher</Button>
              </Link>
            </Card>
          </div>
        )}

        {/* Login prompt for guests */}
        {!user && (
          <div className="mt-12 animate-fade-in">
            <Card className="p-8 text-center border-primary/20">
              <h2 className="font-display text-xl font-bold text-foreground mb-2">
                Create an account to track progress
              </h2>
              <p className="text-muted-foreground mb-6">
                Sign up to save your progress and earn reward vouchers.
              </p>
              <Link to="/register">
                <Button variant="cyber">Sign Up Free</Button>
              </Link>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default TopicDetail;
