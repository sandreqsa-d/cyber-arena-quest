import { Navigate, Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { getCurrentUser, TOPICS } from "@/lib/storage";
import { VoucherCard } from "@/components/VoucherCard";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { User, Trophy, Gamepad2, Brain, Crown, Gift } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

const Profile = () => {
  const [refreshKey, setRefreshKey] = useState(0);
  const user = getCurrentUser();

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  const completedTopics = user.progress.filter(p => p.completed).length;
  const totalGames = user.progress.reduce((acc, p) => acc + p.gameScores.length, 0);
  const totalQuizzes = user.progress.reduce((acc, p) => acc + p.quizScores.length, 0);
  const unclaimedVouchers = user.progress.filter(p => p.completed && !p.voucherClaimed).length;

  return (
    <div className="min-h-screen bg-background cyber-grid">
      <Navbar />
      
      <div className="container mx-auto px-4 pt-32 pb-20">
        {/* Profile Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center gap-6 mb-12 animate-fade-in">
          <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
            <User className="w-12 h-12 text-primary-foreground" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h1 className="font-display text-3xl font-bold text-foreground">
                {user.username}
              </h1>
              {user.subscription !== 'free' && (
                <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-semibold ${
                  user.subscription === 'elite' 
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white' 
                    : 'bg-secondary/20 text-secondary'
                }`}>
                  <Crown className="w-4 h-4" />
                  {user.subscription.charAt(0).toUpperCase() + user.subscription.slice(1)}
                </span>
              )}
            </div>
            <p className="text-muted-foreground">{user.email}</p>
            <p className="text-sm text-muted-foreground mt-1">
              Member since {new Date(user.createdAt).toLocaleDateString()}
            </p>
          </div>
          {unclaimedVouchers > 0 && (
            <div className="px-4 py-2 rounded-full bg-warning/10 text-warning border border-warning/20 flex items-center gap-2">
              <Gift className="w-5 h-5" />
              <span className="font-semibold">{unclaimedVouchers} Unclaimed Voucher{unclaimedVouchers > 1 ? 's' : ''}</span>
            </div>
          )}
        </div>

        {/* Stats Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          {[
            { icon: Trophy, label: 'Topics Completed', value: `${completedTopics}/10`, color: 'text-warning' },
            { icon: Gamepad2, label: 'Games Played', value: totalGames, color: 'text-primary' },
            { icon: Brain, label: 'Quizzes Taken', value: totalQuizzes, color: 'text-secondary' },
            { icon: Gift, label: 'Vouchers Earned', value: completedTopics, color: 'text-accent' },
          ].map((stat, i) => (
            <Card key={i} glow className="p-6">
              <stat.icon className={`w-8 h-8 ${stat.color} mb-4`} />
              <div className="font-display text-2xl font-bold text-foreground">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </Card>
          ))}
        </div>

        {/* Topic Progress */}
        <div className="mb-12 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          <h2 className="font-display text-xl font-semibold text-foreground mb-6">
            Topic Progress
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {TOPICS.map((topic) => {
              const progress = user.progress.find(p => p.topicId === topic.id);
              const total = (progress?.quizScores.length || 0) + (progress?.gameScores.length || 0);
              const percentage = (total / 10) * 100;
              
              return (
                <Link key={topic.id} to={`/topic/${topic.id}`}>
                  <Card glow className="p-4 hover:scale-[1.02] transition-transform">
                    <div className="flex items-center gap-3 mb-3">
                      <span className="text-2xl">{topic.icon}</span>
                      <span className="font-semibold text-sm text-foreground truncate">{topic.name}</span>
                    </div>
                    <Progress value={percentage} className="h-1.5" />
                    <div className="text-xs text-muted-foreground mt-2">
                      {progress?.completed ? '✓ Complete' : `${total}/10`}
                    </div>
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Vouchers Section */}
        <div className="animate-fade-in" style={{ animationDelay: '0.3s' }}>
          <h2 className="font-display text-xl font-semibold text-foreground mb-6 flex items-center gap-2">
            <Gift className="w-5 h-5 text-primary" />
            Reward Vouchers
          </h2>
          
          {completedTopics > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {TOPICS.map((topic) => {
                const progress = user.progress.find(p => p.topicId === topic.id);
                if (!progress?.completed) return null;
                
                return (
                  <VoucherCard
                    key={topic.id}
                    topicId={topic.id}
                    topicName={topic.name}
                    topicIcon={topic.icon}
                    voucherId={topic.voucherId}
                    claimed={progress.voucherClaimed}
                    onClaim={() => setRefreshKey(prev => prev + 1)}
                  />
                );
              })}
            </div>
          ) : (
            <Card className="p-12 text-center border-dashed">
              <Gift className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-display text-lg font-semibold text-foreground mb-2">
                No Vouchers Yet
              </h3>
              <p className="text-muted-foreground mb-6">
                Complete all games and quizzes in a topic to earn reward vouchers.
              </p>
              <Link to="/topics">
                <Button variant="cyber">Start Learning</Button>
              </Link>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;
