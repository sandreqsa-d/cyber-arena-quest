export interface User {
  id: string;
  username: string;
  email: string;
  password: string;
  createdAt: string;
  progress: TopicProgress[];
  subscription: 'free' | 'pro' | 'elite';
}

export interface TopicProgress {
  topicId: string;
  completed: boolean;
  quizScores: number[];
  gameScores: number[];
  voucherClaimed: boolean;
}

export const TOPICS = [
  { id: 'phishing', name: 'Phishing', icon: '🎣', voucherId: '243258', color: 'from-cyan-500 to-blue-600' },
  { id: 'password-strength', name: 'Password Strength', icon: '🔐', voucherId: '846851', color: 'from-purple-500 to-pink-600' },
  { id: 'ransomware', name: 'Ransomware Crisis', icon: '💀', voucherId: '135468', color: 'from-red-500 to-orange-600' },
  { id: 'incorrect-email', name: 'Incorrect Emails', icon: '📧', voucherId: '859387', color: 'from-amber-500 to-yellow-600' },
  { id: 'malware', name: 'Malware Defence', icon: '🛡️', voucherId: '635479', color: 'from-green-500 to-emerald-600' },
  { id: 'social-engineering', name: 'Social Engineering', icon: '🎭', voucherId: '968537', color: 'from-violet-500 to-purple-600' },
  { id: 'wifi-danger', name: 'WiFi Danger Zone', icon: '📶', voucherId: '214365', color: 'from-blue-500 to-cyan-600' },
  { id: 'unupdated-systems', name: 'Unupdated Systems', icon: '⚠️', voucherId: '975132', color: 'from-orange-500 to-red-600' },
  { id: 'spot-the-fake', name: 'Spot the Fake', icon: '🔍', voucherId: '539874', color: 'from-teal-500 to-green-600' },
  { id: 'digital-footprint', name: 'Digital Footprint', icon: '👣', voucherId: '105640', color: 'from-pink-500 to-rose-600' },
];

const USERS_KEY = 'emzariko_users';
const CURRENT_USER_KEY = 'emzariko_current_user';

export function getUsers(): User[] {
  const users = localStorage.getItem(USERS_KEY);
  return users ? JSON.parse(users) : [];
}

export function saveUsers(users: User[]): void {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function getCurrentUser(): User | null {
  const userId = localStorage.getItem(CURRENT_USER_KEY);
  if (!userId) return null;
  const users = getUsers();
  return users.find(u => u.id === userId) || null;
}

export function setCurrentUser(userId: string | null): void {
  if (userId) {
    localStorage.setItem(CURRENT_USER_KEY, userId);
  } else {
    localStorage.removeItem(CURRENT_USER_KEY);
  }
}

export function registerUser(username: string, email: string, password: string): { success: boolean; error?: string } {
  const users = getUsers();
  
  if (users.find(u => u.email === email)) {
    return { success: false, error: 'Email already registered' };
  }
  
  if (users.find(u => u.username === username)) {
    return { success: false, error: 'Username already taken' };
  }

  const newUser: User = {
    id: crypto.randomUUID(),
    username,
    email,
    password,
    createdAt: new Date().toISOString(),
    progress: TOPICS.map(topic => ({
      topicId: topic.id,
      completed: false,
      quizScores: [],
      gameScores: [],
      voucherClaimed: false,
    })),
    subscription: 'free',
  };

  users.push(newUser);
  saveUsers(users);
  setCurrentUser(newUser.id);
  
  return { success: true };
}

export function loginUser(email: string, password: string): { success: boolean; error?: string } {
  const users = getUsers();
  const user = users.find(u => u.email === email && u.password === password);
  
  if (!user) {
    return { success: false, error: 'Invalid email or password' };
  }
  
  setCurrentUser(user.id);
  return { success: true };
}

export function logoutUser(): void {
  setCurrentUser(null);
}

export function updateUserProgress(topicId: string, quizScore?: number, gameScore?: number): void {
  const users = getUsers();
  const currentUserId = localStorage.getItem(CURRENT_USER_KEY);
  
  const userIndex = users.findIndex(u => u.id === currentUserId);
  if (userIndex === -1) return;

  const progressIndex = users[userIndex].progress.findIndex(p => p.topicId === topicId);
  if (progressIndex === -1) return;

  if (quizScore !== undefined) {
    users[userIndex].progress[progressIndex].quizScores.push(quizScore);
  }
  
  if (gameScore !== undefined) {
    users[userIndex].progress[progressIndex].gameScores.push(gameScore);
  }

  // Check if topic is completed (all 5 quizzes and 5 games done)
  const progress = users[userIndex].progress[progressIndex];
  if (progress.quizScores.length >= 5 && progress.gameScores.length >= 5) {
    progress.completed = true;
  }

  saveUsers(users);
}

export function claimVoucher(topicId: string): void {
  const users = getUsers();
  const currentUserId = localStorage.getItem(CURRENT_USER_KEY);
  
  const userIndex = users.findIndex(u => u.id === currentUserId);
  if (userIndex === -1) return;

  const progressIndex = users[userIndex].progress.findIndex(p => p.topicId === topicId);
  if (progressIndex === -1) return;

  users[userIndex].progress[progressIndex].voucherClaimed = true;
  saveUsers(users);
}

export function updateSubscription(plan: 'free' | 'pro' | 'elite'): void {
  const users = getUsers();
  const currentUserId = localStorage.getItem(CURRENT_USER_KEY);
  
  const userIndex = users.findIndex(u => u.id === currentUserId);
  if (userIndex === -1) return;

  users[userIndex].subscription = plan;
  saveUsers(users);
}
