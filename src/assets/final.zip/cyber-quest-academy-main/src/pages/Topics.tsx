import { Navbar } from "@/components/Navbar";
import { TopicCard } from "@/components/TopicCard";
import { TOPICS, getCurrentUser } from "@/lib/storage";
import { Crown } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const Topics = () => {
  const user = getCurrentUser();
  const isPremium = user?.subscription === 'pro' || user?.subscription === 'elite';

  // First 5 topics free, rest require premium
  const freeTopics = TOPICS.slice(0, 5);
  const premiumTopics = TOPICS.slice(5);

  return (
    <div className="min-h-screen bg-background cyber-grid">
      <Navbar />
      
      <div className="container mx-auto px-4 pt-32 pb-20">
        <div className="text-center mb-12">
          <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4 animate-fade-in">
            Learning <span className="text-primary text-glow">Topics</span>
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: '0.1s' }}>
            Master cybersecurity through 10 essential topics. Complete games and quizzes to earn rewards.
          </p>
        </div>

        {/* Free Topics */}
        <div className="mb-12">
          <h2 className="font-display text-xl font-semibold text-foreground mb-6 flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-success" />
            Free Topics
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
            {freeTopics.map((topic, index) => {
              const progress = user?.progress.find(p => p.topicId === topic.id);
              return (
                <TopicCard
                  key={topic.id}
                  id={topic.id}
                  name={topic.name}
                  icon={topic.icon}
                  color={topic.color}
                  index={index}
                  progress={progress ? {
                    quizzes: progress.quizScores.length,
                    games: progress.gameScores.length,
                    completed: progress.completed,
                  } : undefined}
                />
              );
            })}
          </div>
        </div>

        {/* Premium Topics */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-display text-xl font-semibold text-foreground flex items-center gap-2">
              <Crown className="w-5 h-5 text-warning" />
              Premium Topics
            </h2>
            {!isPremium && (
              <Link to="/pricing">
                <Button variant="secondary" size="sm" className="gap-2">
                  <Crown className="w-4 h-4" />
                  Unlock All
                </Button>
              </Link>
            )}
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
            {premiumTopics.map((topic, index) => {
              const progress = user?.progress.find(p => p.topicId === topic.id);
              return (
                <TopicCard
                  key={topic.id}
                  id={topic.id}
                  name={topic.name}
                  icon={topic.icon}
                  color={topic.color}
                  index={index + 5}
                  locked={!isPremium}
                  progress={isPremium && progress ? {
                    quizzes: progress.quizScores.length,
                    games: progress.gameScores.length,
                    completed: progress.completed,
                  } : undefined}
                />
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Topics;
