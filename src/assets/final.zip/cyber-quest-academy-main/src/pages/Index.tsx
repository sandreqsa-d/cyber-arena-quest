import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Navbar } from "@/components/Navbar";
import { Shield, Zap, Trophy, Users, ChevronRight, Lock, Brain, Gamepad2 } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-background cyber-grid">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[128px] animate-pulse-glow" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/20 rounded-full blur-[128px] animate-pulse-glow" style={{ animationDelay: '1s' }} />
        </div>

        <div className="container mx-auto relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/5 text-primary text-sm mb-8 animate-fade-in">
              <Shield className="w-4 h-4" />
              <span>Learn Cybersecurity Through Games</span>
            </div>
            
            <h1 className="font-display text-5xl md:text-7xl font-bold text-foreground mb-6 animate-fade-in" style={{ animationDelay: '0.1s' }}>
              Level Up Your
              <span className="block text-glow bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Cyber Skills
              </span>
            </h1>
            
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 animate-fade-in" style={{ animationDelay: '0.2s' }}>
              Master cybersecurity with interactive games and quizzes. 
              Earn rewards while learning to protect yourself online.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in" style={{ animationDelay: '0.3s' }}>
              <Link to="/register">
                <Button variant="cyber" size="xl" className="w-full sm:w-auto gap-2">
                  Start Learning
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </Link>
              <Link to="/topics">
                <Button variant="glow" size="xl" className="w-full sm:w-auto">
                  Explore Topics
                </Button>
              </Link>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20 animate-fade-in" style={{ animationDelay: '0.4s' }}>
            {[
              { icon: Brain, label: '10 Topics', value: 'To Master' },
              { icon: Gamepad2, label: '50 Games', value: 'Interactive' },
              { icon: Trophy, label: 'Rewards', value: 'Real Prizes' },
              { icon: Users, label: 'Ages 11-25', value: 'Designed For' },
            ].map((stat, i) => (
              <div key={i} className="text-center p-6 rounded-xl border border-border bg-card/50 backdrop-blur-sm hover:border-primary/50 transition-all duration-300">
                <stat.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                <div className="font-display font-bold text-foreground">{stat.label}</div>
                <div className="text-sm text-muted-foreground">{stat.value}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 relative">
        <div className="container mx-auto">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-center text-foreground mb-4">
            How It Works
          </h2>
          <p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto">
            Learn through play. Each topic has games and quizzes to help you understand and master cybersecurity.
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Gamepad2,
                title: 'Play Games',
                description: '5 interactive games per topic teach concepts through hands-on experience.',
                color: 'from-primary to-cyan-400',
              },
              {
                icon: Brain,
                title: 'Take Quizzes',
                description: '5 quizzes per topic test your knowledge with increasing difficulty.',
                color: 'from-secondary to-pink-400',
              },
              {
                icon: Trophy,
                title: 'Earn Rewards',
                description: 'Complete topics to unlock exclusive vouchers from our sponsors.',
                color: 'from-accent to-green-400',
              },
            ].map((feature, i) => (
              <div 
                key={i}
                className="group p-8 rounded-2xl border border-border bg-card hover:border-primary/50 transition-all duration-500 hover:shadow-[0_0_40px_hsl(180_100%_50%_/_0.1)] animate-fade-in"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className="w-7 h-7 text-primary-foreground" />
                </div>
                <h3 className="font-display text-xl font-semibold text-foreground mb-3">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="relative rounded-3xl border border-border bg-gradient-to-br from-card to-muted p-12 text-center overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5" />
            <div className="relative z-10">
              <Lock className="w-16 h-16 text-primary mx-auto mb-6" />
              <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
                Ready to Defend Yourself Online?
              </h2>
              <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
                Join thousands of learners mastering cybersecurity through our gamified platform.
              </p>
              <Link to="/register">
                <Button variant="cyber" size="xl">
                  Create Free Account
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4">
        <div className="container mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-primary" />
            <span className="font-display font-bold text-foreground">EMZARIKO.INC</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © 2024 Emzariko Inc. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
