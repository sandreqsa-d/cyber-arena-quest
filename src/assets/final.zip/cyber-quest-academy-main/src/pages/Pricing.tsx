import { Navbar } from "@/components/Navbar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getCurrentUser, updateSubscription } from "@/lib/storage";
import { Check, Crown, Zap, Shield, Star } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

const plans = [
  {
    id: 'free',
    name: 'Free',
    price: '$0',
    period: 'forever',
    description: 'Perfect for getting started',
    features: [
      '5 Free Topics',
      'Basic Games & Quizzes',
      'Progress Tracking',
      'Earn Vouchers',
    ],
    icon: Shield,
    color: 'from-muted to-muted',
    popular: false,
  },
  {
    id: 'pro',
    name: 'Pro',
    price: '$9.99',
    period: 'per month',
    description: 'Unlock your full potential',
    features: [
      'All 10 Topics',
      'Advanced Games & Quizzes',
      'Priority Support',
      'Exclusive Vouchers',
      'Progress Analytics',
      'Certificate of Completion',
    ],
    icon: Zap,
    color: 'from-primary to-cyan-400',
    popular: true,
  },
  {
    id: 'elite',
    name: 'Elite',
    price: '$19.99',
    period: 'per month',
    description: 'The ultimate learning experience',
    features: [
      'Everything in Pro',
      '1-on-1 Mentorship',
      'Early Access to New Content',
      'Premium Vouchers (2x Value)',
      'Custom Learning Path',
      'Leaderboard Badge',
      'Private Discord Access',
    ],
    icon: Crown,
    color: 'from-amber-500 to-orange-500',
    popular: false,
  },
];

const Pricing = () => {
  const user = getCurrentUser();
  const navigate = useNavigate();
  const [loading, setLoading] = useState<string | null>(null);

  const handleSubscribe = (planId: string) => {
    if (!user) {
      toast.error('Please create an account first');
      navigate('/register');
      return;
    }

    setLoading(planId);
    
    // Simulate payment processing
    setTimeout(() => {
      updateSubscription(planId as 'free' | 'pro' | 'elite');
      toast.success(`Successfully subscribed to ${planId.charAt(0).toUpperCase() + planId.slice(1)} plan!`);
      setLoading(null);
      navigate('/topics');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-background cyber-grid">
      <Navbar />
      
      <div className="container mx-auto px-4 pt-32 pb-20">
        <div className="text-center mb-16 animate-fade-in">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-warning/30 bg-warning/5 text-warning text-sm mb-6">
            <Star className="w-4 h-4" />
            <span>Unlock Premium Features</span>
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
            Choose Your <span className="text-primary text-glow">Plan</span>
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Upgrade to access all topics, advanced features, and exclusive rewards.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={plan.id}
              glow={plan.popular}
              className={`relative overflow-hidden p-8 transition-all duration-500 animate-fade-in ${
                plan.popular ? 'border-primary/50 scale-105' : ''
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Popular badge */}
              {plan.popular && (
                <div className="absolute top-0 right-0 px-4 py-1 bg-gradient-to-r from-primary to-secondary text-primary-foreground text-xs font-bold uppercase rounded-bl-xl">
                  Most Popular
                </div>
              )}

              {/* Gradient background */}
              <div className={`absolute inset-0 bg-gradient-to-br ${plan.color} opacity-5`} />

              <div className="relative z-10">
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-6`}>
                  <plan.icon className="w-7 h-7 text-white" />
                </div>

                <h3 className="font-display text-2xl font-bold text-foreground mb-2">
                  {plan.name}
                </h3>
                <p className="text-muted-foreground text-sm mb-6">
                  {plan.description}
                </p>

                <div className="mb-6">
                  <span className="font-display text-4xl font-bold text-foreground">
                    {plan.price}
                  </span>
                  <span className="text-muted-foreground">/{plan.period}</span>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3 text-sm">
                      <Check className={`w-5 h-5 ${plan.popular ? 'text-primary' : 'text-success'}`} />
                      <span className="text-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  variant={plan.popular ? 'cyber' : 'outline'}
                  className="w-full"
                  size="lg"
                  onClick={() => handleSubscribe(plan.id)}
                  disabled={loading === plan.id || user?.subscription === plan.id}
                >
                  {loading === plan.id ? (
                    'Processing...'
                  ) : user?.subscription === plan.id ? (
                    'Current Plan'
                  ) : (
                    `Get ${plan.name}`
                  )}
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {/* FAQ */}
        <div className="mt-20 max-w-3xl mx-auto animate-fade-in" style={{ animationDelay: '0.4s' }}>
          <h2 className="font-display text-2xl font-bold text-foreground text-center mb-8">
            Frequently Asked Questions
          </h2>
          <div className="space-y-4">
            {[
              { q: 'Can I cancel anytime?', a: 'Yes! You can cancel your subscription at any time. Your access will continue until the end of your billing period.' },
              { q: 'What payment methods do you accept?', a: 'We accept all major credit cards, PayPal, and Apple Pay.' },
              { q: 'Is there a student discount?', a: 'Yes! Students get 50% off all paid plans. Contact us with your student email to get the discount.' },
            ].map((faq, i) => (
              <Card key={i} className="p-6">
                <h3 className="font-semibold text-foreground mb-2">{faq.q}</h3>
                <p className="text-muted-foreground text-sm">{faq.a}</p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pricing;
